@include('header')
<style> 
.about-us{
    margin-left: 14%;
    height: 500px;
    width: 69%;
    padding: -17px 0;
    background: transparent;
    border: solid;
    color: #fff;
    border: 2px solid rgba(255, 255, 255, .2);
    backdrop-filter: blur(20px);
    box-shadow: 0 0 10px rgba(0, 0, 0, .2);
    border-radius: 10px;
}
.pic{
  height: auto;
  width:  302px;
}
.about{
  width: 1130px;
  max-width: 85%;
  margin: 3% auto;
  display: flex;
  align-items: center;
  justify-content: space-around;
}
.text{
  width: 540px;
}
.text h2{
  font-size: 90px;
  font-weight: 600;
  margin-bottom: 10px;

}
.text h5{
  font-size: 22px;
  font-weight: 500;
  margin-bottom: 20px;
}
span{
  color: #2a9191;
}
.text p{
  font-size: 18px;
  line-height: 25px;
  letter-spacing: 1px;
}
.data{
  margin-top: 30px;
}
.hire{
  font-size: 18px;
  background: #2a9191;
  color: #fff;
  text-decoration: none;
  border: none;
  padding: 8px 25px;
  border-radius: 6px;
  transition: 0.5s;
}
.hire:hover{
  background: transparent;
  border: 1px solid #2a9191;
}
</style>
<main >

<section class="about-us">
    <div class="about">
      <!-- <img src="https://cdn.pixabay.com/photo/2016/04/20/03/30/landscape-1340385_640.png" class="pic"> -->
      <img src="https://cdn.pixabay.com/photo/2020/12/16/04/16/girl-5835667_640.jpg" class="pic">
      <div class="text">
        <h2>About Us</h2>
        <h5>Cosmotus & <span>India's #1 Beauty Destination</span></h5>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Expedita natus ad sed harum itaque ullam enim quas, veniam accusantium, quia animi id eos adipisci iusto molestias asperiores explicabo cum vero atque amet corporis! Soluta illum facere consequuntur magni. Ullam dolorem repudiandae cumque voluptate consequatur consectetur, eos provident necessitatibus reiciendis corrupti!</p>
        <div class="data">
        <a href="#" class="hire">Explore</a>
        </div>
      </div>
    </div>
  </section>


</main>
@include('footer')
