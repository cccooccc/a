<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmotus</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
        }

        .header {
            min-height: 100vh;
            width: 100%;
            background-image: linear-gradient(rgba(4, 9, 30, 0.7), rgba(4, 9, 30, 0.7)), url('https://cdn.pixabay.com/photo/2023/06/30/09/09/composition-8097955_640.jpg');
            background-position: center;
            background-size: cover;
            position: relative;
        }

        nav {
            display: flex;
            padding: 2% 6%;
            justify-content: space-between;
            align-items: center;
        }

        nav img {
            width: 75px;
            height: 75px;

        }

        .nav-links {
            flex: 1;
            text-align: right;
        }

        .nav-links ul li {
            list-style: none;
            display: inline-block;
            padding: 8px 12px;
            position: relative;
        }

        .nav-links ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 13px;
            font-family: "Poppins", sans-serif;

        }

        .nav-links ul li::after {
            content: '';
            width: 0%;
            height: 2px;
            background: #2a9191;
            display: block;
            margin: auto;
            transition: 0.5s;
        }

        .nav-links ul li:hover::after {
            width: 100%;
        }

        
        
        nav .fa1{
            display: none;
        }

       
       
    </style>
</head>

<body>
    <section class="header">
        <nav>
            <a href="home.html"><img src="https://cdn.pixabay.com/photo/2023/07/10/21/52/logo-8119185_640.png"
                    alt=""></a>

            <div class="nav-links" id="navlink">
                <svg  xmlns="http://www.w3.org/2000/svg" onclick="close()" width="16" height="16" fill="currentColor" class="bi bi-x-lg fa1" viewBox="0 0 16 16">
                    <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/>
                  </svg>
                <ul>
                    <li><a href="home.php">HOME</a></li>
                    <li><a href="about">ABOUT</a></li>
                    <li><a href="product">PRODUCT</a></li>
                   
                    <li><a href="advice">BEAUTY ADVICE</a></li>
                    
                </ul>
            </div>
            <svg xmlns="http://www.w3.org/2000/svg" onclick="open()" width="16" height="16" fill="currentColor" class="bi bi-list fa1" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
              </svg>
        </nav>