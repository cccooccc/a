@include('header')

<style>
    /* .container {
        position: absolute;
        top: 30%;
        left: 10%;
    } */

    .box {
        position: relative;
    }

    .middle {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        opacity: 0;
        transition: opacity 0.4s ease-in-out;
        background: black;
        cursor: pointer;
    }

    .text {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        color: #fff;
        font-family: verdana;
        text-align: center;
    }

    .box:hover .middle {
        opacity: 0.8;

    }

    .catimg {
        box-shadow: rgba(240, 240, 245, 0.4) 0px 7px 29px 0px;
        border-radius: 10px;
        width: 100%;
        height: 100%;
    }

    .btn {
        margin: 0;
        padding: 0;
        border: 0;
        background: none;

    }
</style>
<main class="text-box">

    <div class="container">
        
            <div class="row">
                @isset($dat)
                @foreach($dat as $k)

                <div class="col-3">
                <a href="product2/{{$k->category}}" >
                        <div class="box">
                            <img src="{{asset('upload')}}/{{$k->catimg}}" class="catimg" alt="" srcset="">

                            <div class="middle">
                                <div class="text">
                                    <h3>{{$k->category}}</h3>
                                    
                                </div>
                            </div>
                        </div>
                    </a >
                
                 
                </div>
                @endforeach
                @endisset
                </div> 
                
                
            
           
    </div>


</main>

<div>
{{$dat->links('pagination::bootstrap-5')}}
</div>

@include('footer')