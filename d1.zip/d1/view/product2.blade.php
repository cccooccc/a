@include('header')

<style>
.avd:hover{
background: #2a9191 !important;
color: antiquewhite !important;
}

.pagination{
    
    align-items: center;
    justify-content: center;
    margin-top: -3px;
}
.pp{
    color: aliceblue;
    background: transparent;
    border: 1px solid #2a9191;
}

.pp:hover{
    color: aliceblue;
    background: #2a9191;
}

.aa{
    background-color: #216969;
}


</style>
<main>
    <div class="container">
        <div class="row">
            
           @isset($dat)
           @if(count($dat)>0)
            @foreach($dat as $product)
           

            <div class="col-3" >
                        <form action="" method="POST">
                            <div class="card " style="width: 287px !important;height: 450px !important; background:transparent; border:2px solid #fff; color:#fff; box-shadow:0px 0px 5px #bababa;">
                                <img src="{{asset('upload')}}/{{$product->proimg}}" width="120px" height="200px" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title">{{$product->pname}}</h5>
                                    <h5 class="card-title">{{$product->price}}</h5>
                                    <p style="width: 252px;height: 100px;" class="card-text">{{$product->des}}</p>
                                       
                                    <button name="cart"  class="btn avd" style=" transition: 0.4s; background: transparent; border: 1px solid #2a9191; color:#fff; width:100%">Add to Cart</button>
                                </div>
                            </div>

                            <input type="hidden" name="hidid" value="{{ $product->pid}}">
                            <input type="hidden" name="hidnm" value="{{ $product->pname}}">
                            <input type="hidden" name="hidpr" value="{{ $product->price}}">
                            <input type="hidden" name="hidimg" value="{{ $product->proimg}}">
                            <input type="hidden" name="hidcat" value="{{ $product->category}}">
                            <input type="hidden" name="hidqty" value="1">
                            </form>
                        </div>



            @endforeach
            @else
            <h4 style='margin:15% 44%; color:#fff'>no product found</h4>

            @endif
           @endisset
                        
            
        </div>
    </div>


  
    
</main>
<div>
{{$dat->links('pagination::bootstrap-5')}}
</div>

@include('footer')