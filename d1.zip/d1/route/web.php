<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Controller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/product', [Controller::class,'product']);
Route::get('/about', [Controller::class,'about']);
Route::get('/advice', [Controller::class,'advice']);
Route::get('/admin', [Controller::class,'dashboard']);
Route::get('/user', [Controller::class,'adminuser']);
Route::post('/delteuser', [Controller::class,'delteuser']);
Route::get('/adminproduct', [Controller::class,'adminproduct']);
Route::get('/admincat', [Controller::class,'admincat']);
Route::get('/adminadvice', [Controller::class,'adminadvice']);
Route::post('/prodadd', [Controller::class,'adminupd']);
Route::post('/catdel', [Controller::class,'catdel']);
Route::post('/adviceupd', [Controller::class,'adviceupd']);



Route::get('/product2/{cat}',[Controller::class,'product2']);
