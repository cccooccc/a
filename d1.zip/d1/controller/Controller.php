<?php

namespace App\Http\Controllers;

//use GuzzleHttp\Psr7\Request;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
//user
    function product(){
        $dat=DB::table('category')->orderBy('cid','desc')->paginate(2);
        return view('product',['dat'=>$dat]);
        
    }
    function about(){
        return view('about');
    }

    function product2($cat){

        $dat=DB::table('products')->where('category',$cat)->orderBy('pid','desc')->paginate(2);
        $i=1;
        return view('product2',['dat'=>$dat]);
        // print_r($dat);
    
    }

    function advice(){
        $dat=DB::table('beauty_advice')->paginate();
       
        return view('advice',['dat'=>$dat]);

    }
//admin
    function dashboard(){
        $cat=DB::table('category')->get();
        $prod=DB::table('products')->get();
        $user=DB::table('users')->get();
        $adv=DB::table('beauty_advice')->get();

       return view('dashboard',['cat'=>$cat,'prod'=>$prod,'user'=>$user,'adv'=>$adv]);
    }

   
    function adminuser(){
        $dat2=DB::table('users')->get();
        $dat=json_decode(json_encode($dat2),true);
        $a=1;
        return view('adminuser',['dat'=>$dat,'a'=>$a]);

    }
    function delteuser(Request $req){
        $uid1=$req->uid;
        $dat2=DB::table('users')->where('user_id',$uid1)->delete();
       
        if(!$dat2){
            echo "<script> alert('User Not Removed')</script>";
        }else{
        echo "<script> alert('User Removed Succesfully')</script>";
        }
        return redirect('user');
    }

    function adminproduct(){
        $dat2=DB::table('products')->get();
        $dat=json_decode(json_encode($dat2),true);
        $a=1;
        return view('adminproduct',['dat'=>$dat,'a'=>$a]);

    }
    // function addadmin(Request $req){
    //     $pname=$req->pn;

    // }
    function adminupd(Request $req){
        if($req->action==='remove'){
            $pid=$req->pid;
            $dat2=DB::table('products')->where('pid',$pid)->delete();
       
            if(!$dat2){
                echo "<script> alert('Product Not Removed')</script>";
                return redirect('adminproduct');
            }else{
            echo "<script> alert('Product Removed Succesfully')</script>";
            return redirect('adminproduct');
            }
        }else if($req->action==='update'){
            $n = $req->nm;
            $c = $req->cat;
            $p = $req->pric;
            $q = $req->qty;
            $d = $req->des;
            $pid = $req->pid;

        }
        
    }

    function admincat(){
        $cat2=DB::table('category')->get();
        $cat=json_decode(json_encode($cat2),true);
        $a=1;
        return view('admincat',['cat'=>$cat,'a'=>$a]);
    }
    function catdel(Request $req){
        $cid=$req->cid;
        $query=DB::table(('category'))->where('cid',$cid)->delete();
        if(!$query){
            echo "<script> alert('Category Not Removed')</script>";
            return redirect('admincat');
        }else{
            echo "<script> alert('Category Removed Succesfully')</script>";
            return redirect('admincat');
        }    

    }

    function adminadvice(){
        $dat2=DB::table('beauty_advice')->get();
        $dat=json_decode(json_encode($dat2),true);
        $a=1;
        return view('adminadvice',['dat'=>$dat,'a'=>$a]);
    }
    function adviceupd(Request $req){
        if($req->action==='remove'){
        $bid=$req->bid;
            
        $query=DB::table(('beauty_advice'))->where('ba_id',$bid)->delete();
            if(!$query){
                echo "<script> alert('Beauty Advice Not Removed')</script>";
                return redirect('adminadvice');
            }else{
                echo "<script> alert('Beauty Advice Removed Succesfully')</script>";
                return redirect('adminadvice');
            }            }
    }


}
